let display = document.getElementById('display');
let ans = '';

function append(val) {
  if (display.innerText === '0') display.innerText = '';
  display.innerText += val;
}

function delChar() {
  display.innerText = display.innerText.slice(0, -1) || '0';
}

function calculate() {
  try {
    ans = eval(display.innerText.replace(/x/g, '*'));
    display.innerText = ans;
  } catch (e) {
    display.innerText = 'Error';
  }
}

function getAns() {
  display.innerText += ans;
}
